//
//  ViewController.swift
//  Curso3Week2Json
//
//  Created by 10.13 on 6/6/17.
//  Copyright © 2017 xgubianas. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{

    @IBOutlet var isbn: UITextField!
    @IBOutlet var titulo: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var authors: UITextView!
    
    override func viewDidLoad() {
        isbn.delegate = self
        titulo.text = ""
        authors.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Make Enter event
        isbn.resignFirstResponder()
        buscarISBN(isbn: isbn.text!)
        return true
    }
    
    
    func buscarISBN(isbn: String)
    {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(isbn)"
        let urlString = URL(string: urls)
        if let url = urlString
        {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error != nil
                {
                    DispatchQueue.main.async
                    {
                        let alert = UIAlertController(title: "Alert", message: "No internet connection", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else
                {
                    DispatchQueue.main.async
                        {
                        if let DataJson = data,
                            let json = try? JSONSerialization.jsonObject(with: DataJson, options: []) as? [String: Any]
                        {
                            if ((json?.keys.count)!>0)
                            {
                                self.authors.text = ""
                                if let ISBN = json?["ISBN:\(isbn)"] as? [String: Any] {
                                    self.titulo.text = ISBN["title"] as? String
                                    self.date.text = ISBN["publish_date"] as? String
                                    if let authors = ISBN["authors"] as? [[String: Any]] {
                                        for author in authors {
                                            if let name = author["name"] as? String{
                                                self.authors.text! += name + "\n"
                                            }
                                        }
                                    }
                                }
                                
                            }
                            else
                            {
                                let alert = UIAlertController(title: "Alert", message: "ISBN NOT FOUND", preferredStyle: UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                            
                        }
                    }
                }
            }
            task.resume()
        }
    }
}

