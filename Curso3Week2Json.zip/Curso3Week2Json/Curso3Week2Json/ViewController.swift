//
//  ViewController.swift
//  Curso3Week2Json
//
//  Created by 10.13 on 6/6/17.
//  Copyright © 2017 xgubianas. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

 
    @IBOutlet var isbn: UITextField!

    @IBOutlet var titulo: UILabel!
    
    @IBOutlet var autores: UILabel!
    
    @IBAction func buscarDatos(_ sender: Any) {
        buscarISBN(isbn: isbn.text!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.isbn.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func buscarISBN(isbn: String)
    {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + isbn
        let url = NSURL(string: urls)
        let datos = NSData(contentsOf: url! as URL)
        print (datos as Any)
        
        do
        {
            //var autors: String = ""
            let json = try JSONSerialization.jsonObject(with: datos! as Data, options: JSONSerialization.ReadingOptions.allowFragments)
            print (json)
            let isbn_text : String = "ISBN:"+isbn
            let dico1 = json as! NSDictionary
            let dico2 = dico1[isbn_text] as! NSDictionary
            titulo.text = dico2["title"] as! NSString as String
            
            let dico3 = dico1[isbn_text] as! NSDictionary
            
            if let arrJSON = dico3["authors"] as! [String : NSArray]
            {
                for index in 0...arrJSON.count-1
                {
                    let aObject = arrJSON[index] as! [String: Any]
                    print (aObject["name"] as! String)
                }
            }
        }
        catch _
        {
            
        }
        
    }


}

